//
//  DataType.h
//  DooyaSDKID
//
//  Created by moorgen on 2016/12/15.
//  Copyright © 2016年 dooya. All rights reserved.
//

#ifndef DataType_h
#define DataType_h
#import "DeviceInfo.h"
#import "RoomInfo.h"
#import "HubInfo.h"
#import "SceneInfo.h"
#import "STRDeviceInfo.h"
#import "TimerInfo.h"
#import "FavoriteInfo.h"
#import "LocationInfo.h"
#import "Result.h"
#import "RoomCtrlInfo.h"
#import "UserInfo.h"


#endif /* DataType_h */
